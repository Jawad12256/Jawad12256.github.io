import f1isHero from '../assets/images/achievements/f1is/hero.png';
import bandsaw from '../assets/images/achievements/f1is/bandsaw.png';
import cfd from '../assets/images/achievements/f1is/cfd.png';
import fea from '../assets/images/achievements/f1is/fea.png';
import technicaldrawing from '../assets/images/achievements/f1is/technicaldrawing.png';
import winner from '../assets/images/achievements/f1is/winner.png';
import uksdcHero from '../assets/images/achievements/uksdc/hero.png';
import mpdthruster from '../assets/images/achievements/uksdc/mpd-thruster.png';
import photobioreactor from '../assets/images/achievements/uksdc/photobioreactor.png';
import technicaldrawing2 from '../assets/images/achievements/uksdc/technicaldrawing2.png';

export const achievements = [
    {
        id: 'uk-space-design',

        title: 'UK Space Design Competition',

        category: 'Competition',

        year: '2024',

        award: 'National 1st Place',

        recognition:
            'Quality of Visual Communication Award',

        shortDescription:
            'National-winning space settlement design competition project.',

        description:
            'The UKSDC National Finals 2024 demanded me to work with a team of 50 never-met-before students to design Arial, a moon-based space tether settlement. I proposed the design of our autonomous construction and maintenance robots, including an innovative modular approach which enabled old, decommissioned hardware to be reused in a circular economy model. If a sudden influx of 500 new ultrasonic stir welding robots was required, then rather than collecting dust, those unused robots would be deconstructed, maximising resource efficiency in a critical environment. From a commercial perspective, I highlighted the potential for Arial to conduct batch manufacture of magnetoplasmadynamic (MPD) thrusters by exploiting lunar titanium reserves - less Moon-to-Earth transport logistics, more in-house manufacturing and commercial drive. Overall, these clever design decisions secured us a National 1st place finish and I personally was awarded the Quality of Visual Communication Award for my CAD and visualisation work!',

        skills: [
            'Problem Solving',
            'CAD',
            'Systems Design',
            'Visual Communication',
            'Teamwork',
            'Presentation'
        ],

        images: [
            {
                src: image1,
                alt: '',
                caption: ''
            },
        ],
    },

    {
        id: 'f1-in-schools',

        title: 'F1 in Schools',

        category: 'Competition',

        year: '2024',

        award: 'Regional 1st Place',

        shortDescription:
            'Competitive engineering and design project, building an F1-inspired miniature race car.',

        description:
            'As the manufacturing manager for my team, I was primarily responsible for the CNC routing, high-quality finishing, and component assembly for our car. I played a pivotal role in the iterative design process for our car, aided by CFD analysis work using Ansys Fluent. Our team developed a deep-learning algorithm interfacing with Ansys to optimise our aerofoil\'s shape, resulting in a significant reduction in drag and an increase in downforce. To fund our endeavours, we launched effective marketing material and secured several sponsorships. Our efforts culminated in a successful regional competition, where we proudly achieved 1st place, showcasing our engineering prowess and teamwork.',

        skills: [
            'CAD',
            'Engineering Design',
            'Teamwork',
            'Manufacturing'
        ],

        images: [
            {
                src: image1,
                alt: '',
                caption: ''
            },
        ],
    },

    {
        id: 'student-robotics',

        title: 'Student Robotics',

        category: 'Competition',

        year: '2025',

        award: 'Quarter Finalists',

        shortDescription:
            'Robotics competition for 16-18 year olds, building a robot virtually from scratch.',

        description:
            'Working alongside my school\'s robotics team, we worked to design, program, and manufacture an autonomous 2-wheel-drive robot to compete in the arena. The robot was tasked with stacking AprilTag-ged boxes in specific zones of the arena. A months-long iterative design process led us to settle on using two servo-controlled lifting + clamping arms. One of the most interesting issues we ran into was the boxes slipping out of grip, which we cleverly solved by gluing kitchen sponges to the arms for that extra friction. On the programming side, I introduced an agile approach for our team to rapidly develop control, sensing, navigation, and strategy code in tandem. Ultimately, Girafferey the robot put up fierce competition in all its 1v1v1v1 matches, and we were proud to reach the quarter finals of the competition.',

        skills: [
            'CAD',
            'Engineering Design',
            'Teamwork',
            'Manufacturing'
        ],

        images: [
            {
                src: image1,
                alt: '',
                caption: ''
            },
        ],

        links: [
            'https://www.saintolaves.net/81/latest-news/post/1115/student-robotics-over-easter'
        ]
    }

];