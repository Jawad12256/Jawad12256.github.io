export const events = [

    {
        id: 'iosdc',

        title: 'Interhouse Olaves Space Design Competition',

        shortTitle: 'IOSDC',

        year: '2024',

        role: 'Organiser',

        description:
            'WRITE WHAT YOU ORGANISED, YOUR RESPONSIBILITIES, SCALE, ETC.',

        skills: [
            'Leadership',
            'Event Organisation',
            'Communication',
            'Teamwork'
        ],

        images: []
    }

];