export const experience = [

    {
        id: 'software-internship',

        organisation: 'Gemba Advantage',

        role: 'Software Engineering Intern',

        period: 'Summer 2026',

        type: 'Internship',

        shortDescription:
            'WRITE SHORT DESCRIPTION.',

        description:
            'WRITE FULL DESCRIPTION.',

        projects: [
            {
                id: 'trivyal',
                title: 'Trivyal',
                description: '...',
                technologies: '',
                skills: '',
                images: '',
            },

            {
                id: 'cyphon',
                title: 'Cyphon',
                description: '...',
                technologies: '',
                skills: '',
                images: '',
            }
        ],

        technologies: [
            'React',
            'AWS',
            'JavaScript',
            'MongoDB',
            'Trivy'
        ],

        skills: [
            'Software Engineering',
            'Full-Stack Development',
            'Cybersecurity',
            'Cloud Computing',
            'REST APIs'
        ],

        images: [],

        links: {
            website: '...'
        }
    },

    {
        id: 'tutoring',

        role: 'Private Tutor',

        period: '2024 - Present',

        type: 'Teaching',

        shortDescription:
            'Private tutoring in mathematics and physics at GCSE and A-Level, helping students to achieve their academic goals.',

        description:
            'I\'ve been tutoring students in GCSE and A-Level mathematics and physics for several years now. I think that the art of really drilling down into a single student\'s understanding is super important to master in order for lessons to be pitched at exactly the right level. Getting students to apply metacognitive strategies enables them to expect exactly what\'s on the mark scheme and what common mistakes students might make, before they even attempt a question. Hence my approach has always been exam-centric and student-tailored. Overall, I\'ve been able to confidently help students achieve plenty of A*s and Grade 9s. And I take the greatest pleasure not in the results, but in knowing that my students found useful new persepctive in my lessons (I always ask about it at the end of every lesson!)',

        technologies: [
            'PowerPoint',
            'Desmos',
            'PheT Simulations',
        ],

        skills: [
            'Teaching',
            'Communication',
            'Metacognition',
            'Mentoring'
        ],

        images: [],

        links: {}
    },

    {
        id: 'academic-representative',

        role: 'Academic Representative',

        period: '2025 - Present',

        type: 'Leadership',

        shortDescription:
            'Academic representative for my undergraduate cohort, acting as the bridge between students and faculty.',

        description:
            'Since the year I got here, I\'ve been serving as academic representative for my Deisgn Engineering undegraduate cohort at Imperial College London. I acted as a key bridge between students and departmental leadership to drive improvements across the degree program. During my tenure, I represented cohort interests in Staff-Student Committee (SSC) meetings, directly addressed course and delivery issues with module leads, and supported peers through university administrative processes like mitigating circumstances. Beyond formal governance, I actively managed student communications, created supplementary academic learning resources - such as exam walkthrough tutorials - and advocated for practical improvements to department spaces and facilities, such as power banks in our main lecture hall.',

        technologies: [
            'PowerPoint',
            'Desmos',
            'PheT Simulations',
        ],

        skills: [
            'Teaching',
            'Communication',
            'Metacognition',
            'Mentoring'
        ],

        images: [],

        links: {}
    }

];