[

    {
        id: 'unique-project-id',
        title: 'Project Name',
        category: 'Category',
        year: '2026',
        type: 'University Project',
        featured: true,
        shortDescription:
            'ONE OR TWO SENTENCES FOR THE PROJECT CARD.',
        description:
            'THE FULL DESCRIPTION THAT WILL APPEAR IN THE MODAL.',
        technologies: [
            'Python',
            'React',
            'CAD'
        ],
        skills: [
            'Problem Solving',
            'Systems Design',
            'Programming'
        ],
        images: [
            {
                src: image1,
                alt: 'DESCRIPTION OF IMAGE',
                caption: 'CAPTION SHOWN IN GALLERY'
            },

            {
                src: image2,
                alt: 'DESCRIPTION OF IMAGE',
                caption: 'ANOTHER CAPTION'
            }
        ],
        links: {
            github: 'GITHUB URL',
            website: 'WEBSITE URL'
        }
    }


    
]